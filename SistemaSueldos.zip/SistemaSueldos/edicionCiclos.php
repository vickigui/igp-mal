<?php
include "database.php";

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Editar Ciclo</title>
  </head>
  <body>
    <form class="" action="index.html" method="post">
      <label>Descripción Larga</label>
      <input type="text" name="T_DESC_LARG" value="">

      <label>Descripción Corta</label>
      <input type="text" name="T_DESC_CORT" value="">
    </form>

  </body>
</html>
